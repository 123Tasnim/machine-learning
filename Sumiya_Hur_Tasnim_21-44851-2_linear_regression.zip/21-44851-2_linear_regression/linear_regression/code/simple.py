import argparse
import numpy as np
from matplotlib import pyplot as plt

def mean_std(X):
    mean = np.mean(X, axis=0)
    std = np.std(X, axis=0)
    return mean, std

def standardize(X, mean, std):
    S = (X - mean) / std
    return S

def read_data(file_name):
    data = np.loadtxt(file_name)
    X = data[:, :-1]  # Assuming the last column is the target/label
    t = data[:, -1]
    return X, t

def compute_gradient(X, t, w):
    N = len(t)
    predictions = X.dot(w)
    errors = predictions - t
    grad = (1 / N) * X.T.dot(errors)
    return grad

def compute_cost(X, t, w):
    N = len(t)
    predictions = X.dot(w)
    errors = predictions - t
    cost = (1 / (2 * N)) * np.dot(errors.T, errors)
    return cost

def train(X, t, eta, epochs):
    w = np.zeros(X.shape[1])
    costs = []
    ep = []
    for epoch in range(epochs):
        grad = compute_gradient(X, t, w)
        w -= eta * grad
        if epoch % 10 == 0:
            cost = compute_cost(X, t, w)
            costs.append(cost)
            ep.append(epoch)
    return w, ep, costs

def compute_rmse(X, t, w):
    cost = compute_cost(X, t, w)
    rmse = np.sqrt(2 * cost)
    return rmse

def train_SGD(X, t, eta, epochs):
    costs = []
    ep = []
    w = np.zeros(X.shape[1])
    for epoch in range(epochs):
        for i in range(len(t)):
            idx = np.random.randint(len(t))
            X_i = X[idx:idx+1]
            t_i = t[idx:idx+1]
            grad = compute_gradient(X_i, t_i, w)
            w -= eta * grad
        if epoch % 10 == 0:
            cost = compute_cost(X, t, w)
            costs.append(cost)
            ep.append(epoch)
    return w, ep, costs

parser = argparse.ArgumentParser('Simple Regression Exercise.')
parser.add_argument('-i', '--input_data_dir', type=str, default='./data/simple', help='Directory for the simple houses dataset.')
FLAGS, unparsed = parser.parse_known_args()

# Read the training and test data.
Xtrain, ttrain = read_data("D:/Uni_Semester/Semester 9/Final/Machine Learning/linear_regression/data/simple/train.txt")
Xtest, ttest = read_data("D:/Uni_Semester/Semester 9/Final/Machine Learning/linear_regression/data/simple/test.txt")


# Feature scaling
mean_train, std_train = mean_std(Xtrain)
Xtrain = standardize(Xtrain, mean_train, std_train)
Xtest = standardize(Xtest, mean_train, std_train)

# Add bias term
Xtrain = np.c_[np.ones(Xtrain.shape[0]), Xtrain]
Xtest = np.c_[np.ones(Xtest.shape[0]), Xtest]

# Gradient Descent parameters
eta = 0.1
epochs = 200

w, eph, costs = train(Xtrain, ttrain, eta, epochs)
wsgd, ephsgd, costssgd = train_SGD(Xtrain, ttrain, eta, epochs)

# Outputs
print('Params GD: ', w)
print('Params SGD: ', wsgd)

print('Training RMSE: %0.2f.' % compute_rmse(Xtrain, ttrain, w))
print('Training cost: %0.2f.' % compute_cost(Xtrain, ttrain, w))
print('Test RMSE: %0.2f.' % compute_rmse(Xtest, ttest, w))
print('Test cost: %0.2f.' % compute_cost(Xtest, ttest, w))

# Plotting epochs vs. cost for gradient descent methods
plt.figure()
plt.xlabel('Epochs')
plt.ylabel('Cost')
plt.yscale('log')
plt.plot(eph, costs, 'bo-', label='Train J(w) GD')
plt.plot(ephsgd, costssgd, 'ro-', label='Train J(w) SGD')
plt.legend()
plt.savefig('gd_cost_simple.png')
plt.show()

# Plotting linear approximation
plt.figure()
plt.xlabel('Floor sizes')
plt.ylabel('House prices')
plt.scatter(Xtrain[:, 1], ttrain, color='blue', label='Training data')
plt.scatter(Xtest[:, 1], ttest, color='green', label='Test data')
plt.plot(Xtrain[:, 1], Xtrain.dot(w), 'b-', label='GD')
plt.plot(Xtrain[:, 1], Xtrain.dot(wsgd), 'r-', label='SGD')
plt.legend()
plt.savefig('train-test-line.png')
plt.show()
